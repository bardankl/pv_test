import React, {Component} from 'react';



class HeaderMenu extends React.Component {
    constructor() {
        super();
        this.state = {
            isOpen: true
        }
    this.x =this.x.bind(this);
    }


    showSettings(event) {
        event.preventDefault()
    }

    x () {
        this.setState({isOpen: !this.state.isOpen});
        alert(this.state.isOpen)
    }

    render() {
        return (
           <button id="btn" onClick={this.x}>PRESSSSSS</button>
        );
    }
}

export default HeaderMenu;
