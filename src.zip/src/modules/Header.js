import React, {Component} from 'react';
import {Link} from "react-router-dom";
import './Header.css';
import HeaderMenu from './HeaderMenu';

class Header extends Component {
    constructor() {
        super();
        this.state = {
            isOpen: true,
        };
        this.toggleMenu = this.toggleMenu.bind(this)
    }


    componentWillMount() {
    }
//todo it's for contacts pop-up.
    //https://archakov.im/post/detect-click-outside-react-component.html

    toggleMenu() {
    let screenWidth = document.body.clientWidth;

    if(screenWidth<=768) {
        this.setState({isOpen: this.state.isOpen});
        console.log(`work`)
    }else{
        console.log(`not`)
    }
    };

    render() {
        return (
            <div id='containerHeader'>
                <div className="headerContainer">
                    <div className="headerContainerImgWrapper">
                        <img id="headerContainerImg" src={require('../img/header.png')} alt="headerIMG"/>
                    </div>
                    <img className="headerContainerBlackOut" src={require("../img/Rectangle_8.png")} alt={'image'}/>
                    <div className="headerItemInstagram">
                        <a href="#"><img src={require("../img/Instagram-header.png")} alt="hotdog"/></a>
                        <p><a href="#">#hotdogs</a></p>
                    </div>
                </div>
                <nav id="page-nav" className="headerMenu">

                    <label htmlFor="hamburger">&#9776;</label>
                    <input onClick={this.toggleMenu} type="checkbox" id="hamburger"/>

                    (
                    {!this.state.isOpen ?
                        null :
                        (
                            <ul className={this.state.isOpen ? " ":"invisible"}>
                            <li onClick={this.toggleMenu}><Link to={'/'}>MENU</Link></li>
                            <li onClick={this.toggleMenu}><Link to={'/'}>CATERING</Link></li>
                            <li onClick={this.toggleMenu}><Link to={''}>ABOUT US</Link></li>
                            <li onClick={this.toggleMenu}><Link to={'/contact'}>CONTACT</Link></li>
                        </ul>
                        )
                    }
                    )
                </nav>
            </div>)
    }

};

export default Header;
